/*
#include<iostream>
using namespace std;
class student
{
    int roll_no,index;           // data members
    string name;
    int marks;
public:
    void get_data(int i,int a,string b,int c)    // member functions
    {
        index=i;
        roll_no=a;
        name=b;
        marks=c;
    }
    void display()
    {
        cout<<"\nstudent Detail : ";
        cout<<index<<"\n Student roll_no is : "<<roll_no<<"\n student name is : "<<name<<"\n Student marks are : "<<marks<<endl;
    }
};
int main()
{
    student s,s1,s2;
    s.get_data(1,39,"Tejas",100);
    s.display();
    s1.get_data(2,40,"Harshal",96);
    s1.display();
    s2.get_data(3,41,"Smeet",40);
    s2.display();
    return 0;
}
*/
