#include <iostream>
#include <string>
using namespace std;
class Vehicle {
  public:
    string brand = "Ford";
    void speed() {
      cout << "Speed:200 kmph" ;
    }
};

class Car: public Vehicle {
  public:
    string model = "Mustang\n";

};
 class Vehicledetails:public Vehicle{
    public:
        int model,price;
        void details(){
            cout<<"Enter model of car:"<<endl;
            cin>>model;
            cout<<"Enter price of car:"<<endl;
            cin>>price;
        }


 };

int main() {
  Car myCar;
  myCar.speed();
  cout << myCar.brand + " \n" + myCar.model;
  Vehicledetails dd;
  dd.details();
  return 0;
}

