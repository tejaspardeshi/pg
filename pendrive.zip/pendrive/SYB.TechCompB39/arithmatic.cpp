/*
#include<iostream>
using namespace std;
int main()
{
    int a,b,bit;
    bool result;


    cout<<"enter The Two numbers :\n";
    cin>>a>>b;

    cout<<"\n******* The Arithmatic Operators *******\n"<<endl;
    cout<<"The Sum of two Numbers is :"<<a+b<<endl;
    cout<<"The Subtraction of two Numbers is :"<<a-b<<endl;
    cout<<"The Product of two Numbers is :"<<a*b<<endl;
    cout<<"The divide of two Numbers is :"<<a/b<<endl;
    cout<<"The Reminder is :"<<a%b<<endl;

    cout<<"\n******* The Relational Operators *******\n"<<endl;
    result = (a==b);
    cout<<"The output of a==b is : "<<result<<endl;
    result = (a!=b);
    cout<<"The output of a!=b is : "<<result<<endl;
    result = (a>b);
    cout<<"The output of a>b is  : "<<result<<endl;
    result = (a<b);
    cout<<"The output of a<b is  : "<<result<<endl;
    result = (a>=b);
    cout<<"The output of a>=b is : "<<result<<endl;
    result = (a<=b);
    cout<<"The output of a<=b is : "<<result<<endl;

    cout<<"\n******* The Logic Operators *******\n"<<endl;
    result = (a==b) && (a>b);
    cout<<"The output of (a==b) && (a>b) is : "<<result<<endl;
    result = (a==b) || (a>b);
    cout<<"The output of (a==b) || (a>b) is : "<<result<<endl;
    result = (a==b) != (a>b);
    cout<<"The output of (a==b) != (a>b) is : "<<result<<endl;

    cout<<"\n******* The Bitwise Operators *******\n"<<endl;
    bit = (a&b);
    cout<<"The output of (a&b) is : "<<bit<<endl;
    bit = (a|b);
    cout<<"The output of (a|b) is : "<<bit<<endl;
    bit = !(a>b);
    cout<<"The output of != (a>b) is : "<<bit<<endl;



    return 0;
}
*/

