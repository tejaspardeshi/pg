/*
#include <iostream>
#include <string>
using namespace std;
class Vehicle
{
  public:
    string brand = "Ford";
    void speed()
    {
      cout <<"Car Speed : 200 km/h" ;
    }
};
// Derived class
class Car: public Vehicle
{
  public:
    string model = "Lamborgini";
};

int main()
{
  Car myCar;
  myCar.speed();
  cout <<"\nCar brand : "<<myCar.brand +"\nCar model : "+ myCar.model;
  return 0;
}
*/
