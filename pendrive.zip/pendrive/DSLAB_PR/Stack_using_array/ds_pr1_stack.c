#include<stdio.h>
#include<stdlib.h>

int stack[100], i, j, n, choice=0, top=-1;

void push();
void pop();
void show();
void main()
{
    printf("Enter the size of Stack less than 100 : ");
    scanf("%d",&n);

    while(choice!=4)
    {
        printf("\n*****MENU of Operation that you want*****\n");
        printf("\n 1.push\n 2.pop\n 3.show\n 4.exit\n");
        printf("\nEnter your choice among 1 to 4 : ");
        scanf("%d",&choice);

        switch(choice)
        {
        case 1: push();
        break;
        case 2: pop();
        break;
        case 3: show();
        break;
        case 4: exit(0);
        break;
        default : printf("\nPlease Enter The Valid Input \n");
        break;
        }
    }
}

void push()
{
    int value;
    if(top == n-1)
    {
        printf("\nOverflow\n");
    }
    else
    {
        printf("\nEnter the Values to add : ");
        scanf("%d",&value);
        printf("%d is added successfully in stack\n",value);
        top++;
        stack[top] = value;
    }
}

void pop()
{
    if(top == -1)
    {
        printf("\nUnderflow\n");
    }
    else
    {
        printf("%d is remove successfully from stack\n",stack[top]);
        top--;
    }
}

void show()
{
    if(top == -1)
    {
        printf("\nEmpty\n");
    }
    else
    {
        for(i=top ; i>=0 ; i--)
        {
            printf("The %d is present in stack\n",stack[i]);
        }
    }
}
