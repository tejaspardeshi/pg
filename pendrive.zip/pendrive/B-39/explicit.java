import java.util.Scanner;
class explicit
{
	public static void main(String[] svkm)
	{
		Scanner s= new Scanner(System.in);
		float n;
		int m;
		System.out.println("Enter the float value of n: ");
		n=s.nextFloat();
		m=(int)n;
		System.out.println("The integer value of n: "+m);
		
	}
	
}