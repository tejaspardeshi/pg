class swap
{
int a=10,b=20;
public static void main(String[] args)
{

swap o=new swap();
System.out.println("Before Swapping a = "+o.a + " and b = "+o.b);

o.a=o.a+o.b;	//a=a+b
o.b=o.a-o.b;	//b=a-b
o.a=o.a-o.b;	//a=a-b

System.out.println("After Swapping a = "+o.a +" and b = " +o.b);
}
}

