import java.util.Scanner;                     // if we know such as scanner,... then use it, otherwise use *
class pr2
{
	public static void main(String[] svkm)        // here we use any name inplace of args because it is variable name of String
	{
		int x;
		String y;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your Roll Number : ");
		x=s.nextInt();
		System.out.println("Enter your Name : ");
		y=s.next();
		System.out.println("Your Roll Number is : "+x+ " Your Name is : "+y);
	}
}










