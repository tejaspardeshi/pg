import java.util.Scanner;
class mcall
{
	public static void main(String[] svkm)
	{
		Scanner s= new Scanner(System.in);
		int d;
		System.out.println("enter the value of d: ");
		d=s.nextInt();
		mcall obj= new mcall();
		obj.area(d);
		obj.even_odd(d);
		obj.add(d);
		obj.fact(d);
	}
	void area(int a)
	{
		System.out.println("Program on area of square");
		int p=a*a;
		System.out.println("The area of square is : "+p);
	}
	void even_odd(int b)
	{
		System.out.println("Program on even odd number");
		if(b%2==0)
		System.out.println("even number"+b);
		else
		System.out.println("odd number"+b);
	}
	void add(int c)
	{
		System.out.println("Program on addition");
		int r=c+2;
		System.out.println("addition of d+2 is: "+r);
	}
	void fact(int n)
	{
		System.out.println("Program on factorial");
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println("Factorial is: "+fact);

	}
}