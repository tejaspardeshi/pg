import java.util.Scanner;
class string 
{
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
String college, branch;

System.out.println("Enter your College name: ");
college = s.next();
System.out.println("Enter your Branch name: ");
branch = s.next();

System.out.println("Length of college is: "+college.length());
System.out.println("Length of branch is: "+branch.length());
System.out.println("Lower case of college is: "+college.toLowerCase());
System.out.println("Upper case of college is: "+college.toUpperCase());

if(college.equals(branch))
{
	System.out.println("College name & branch name is same");
}
else
{
	System.out.println("College name & branch name are not same");
}

System.out.println("The character at index 4 is: "+college.charAt(4));

if(college.equalsIgnoreCase(branch))
{
	System.out.println("college and branch name are same irrespect of case");
}
else
{
	System.out.println("college and branch name are different even irrespect of case");
}

System.out.println("college string compare to branch string is: "+college.compareTo(branch));

}
}