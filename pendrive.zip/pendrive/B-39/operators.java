import java.util.Scanner;
class operators
{
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
int x,y;
System.out.println("Enter the value of x : ");
System.out.println("Enetr the value of y : ");
x=s.nextInt();
y=s.nextInt();
System.out.println("*****Arithmetic Operators*****");
System.out.println("The value of x+y = "+(x+y));
System.out.println("The value of x-y = "+(x-y));
System.out.println("The value of x*y = "+(x*y));
System.out.println("The value of x/y = "+(x/y));
System.out.println("The value of x%y = "+(x%y));

System.out.println("*****Relational Operators*****");
System.out.println("The value of x<y = "+(x<y));
System.out.println("The value of x>y = "+(x>y));
System.out.println("The value of x<=y = "+(x>=y));
System.out.println("The value of x>=y = "+(x>=y));
System.out.println("The value of x==y = "+(x==y));
System.out.println("The value of x!=y = "+(x!=y));
}
}
