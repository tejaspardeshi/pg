import java.util.*;
class A 
{
void show()
{
	System.out.println("This is A class");
}
}

class B extends A
{
void display()
{
	System.out.println("This is B class");
}
}

class C extends B
{
void print()
{
	System.out.println("This is C class");
}

public static void main(String[] args)
{
	C obj = new C();
	obj.show();
	obj.display();
	obj.print();
}
}
