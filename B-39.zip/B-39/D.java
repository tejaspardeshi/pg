import java.util.Scanner;
class A
{
void show()
{
	System.out.println("This is A parent class");
}
}

class B extends A
{
void display()
{
	System.out.println("This is C1 child of A");
}
}

class D extends A
{
void showw()
{
	System.out.println("This is C2 child of A");
}

public static void main(String[] args)
{
	D obj = new D();
	obj.show();
	obj.display();
	obj.showw();
}
}
