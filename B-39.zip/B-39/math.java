import java.util.Scanner;
class math
{
public static void main(String[] args)
{
Scanner s= new Scanner(System.in);
int x,y;
float f;

System.out.println("Enter value of x: ");
x=s.nextInt();
System.out.println("Enter value of y: ");
y=s.nextInt();
System.out.println("Enter value of f: ");
f=s.nextFloat();


System.out.println("The square root of x is: "+Math.sqrt(x));
System.out.println("The square root of y is: "+Math.sqrt(y));

System.out.println("The value of x^y is: "+Math.pow(x,y));
System.out.println("The value of x^2 is: "+Math.pow(x,2));
System.out.println("The value of y^2 is: "+Math.pow(y,2));

System.out.println("The floor value of f is: "+Math.floor(f));

System.out.println("The ceil value of f is: "+Math.ceil(f));

System.out.println("The sin of x is: "+Math.sin(x));
System.out.println("The cos of y is: "+Math.cos(y));

System.out.println("The sin of x is: "+Math.min(x,y));
System.out.println("The cos of y is: "+Math.max(x,y));

System.out.println("The sin of x is: "+Math.round(x));
System.out.println("The sin of x is: "+Math.round(x));

System.out.println("Random value betewwn 1 to 1000: "+ramdom(1,1000));


}
}