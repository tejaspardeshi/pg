import java.util.Scanner;
class parent 
{
Scanner s = new Scanner(System.in);
int y= 10;    // static int y = 10 ;then does not need object 
int x;
System.out.println("Enter value of x ");
x = s.nextInt();

x =s.nextInt();

void show()
{
	System.out.println("This is the parent class");
}
}
class child extends parent
{
void display()
{
	System.out.println("This is the child class");
}
public static void main(String[] args)
{
	child obj = new child();
	obj.show();
	obj.display();

	System.out.println("The value of x ="+y.obj);
	System.out.println("The value of x ="+x.obj);
}
}
