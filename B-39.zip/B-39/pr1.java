class pr1
{
public static void main(String[] args)
{
int y=30,x=80;
int z=x+y;
System.out.println("The sum of x and y is" +z);
}
}