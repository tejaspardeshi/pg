// multiple inheritance
interface A
{
	void show();
}

interface B
{
	void display();
}

class interf implements A,B
{
	public void show()
	{
		System.out.println("I am interface method of A");
	}
	public void display()
	{
		System.out.println("I am interface method of B");
	}

	public static void main(String[] args)
	{
		interf obj = new interf();
		obj.show();
		obj.display();
	}

}