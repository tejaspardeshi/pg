import java.util.Scanner;
class implicit
{
	public static void main(String[] svkm)
	{
		Scanner s= new Scanner(System.in);
		int i;
		float f;
		System.out.println("Enter the value of i: ");
		i=s.nextInt();
		f=i;
		System.out.println("The value of i: "+i);
		System.out.println("The value of f: "+f);
	}
	
}