#include<stdio.h>
#define MAXSIZE 2
int deq[MAXSIZE], rear = -1, front = -1;

void enqueue();
void dequeue();
void display();
int main()
{
    int choice;
    printf("\n--------------------------CIRCULAR QUEUE MENU---------------------");
    printf("\n1] Enqueue  \n2] Dequeue  \n3] Display \n4] Exit");

    do
    {
        printf("\nEnter choice: ");
        scanf("%d", &choice);
        switch(choice)
		{
            case 1: enqueue(); break;
            case 2: dequeue(); break;
            case 3: display(); break;
            case 4: printf("\nExiting...\n"); break;
            default: printf("\nInvalid operation\n");
        }
    } while(choice != 4);

    return 0;
}

void enqueue()
{
    int n;
    if((rear + 1) % MAXSIZE == front)
	{
        printf("\nCIRCULAR QUEUE IS FULL\n");
    }
	else
	{
        printf("\nEnter the element: ");
        scanf("%d", &n);
        printf("\n%d is added in circular queue\n",n);

        if(front == -1 && rear == -1)
		{
            front = rear = 0;
        }
        else
        {
            rear = (rear + 1) % MAXSIZE;
        }
        deq[rear] = n;
    }
}

void dequeue()
{
    int n;
    if(front == -1 && rear == -1)
	{
        printf("\nCIRCULAR QUEUE IS EMPTY\n");
    }
	 else
	  {
        n = deq[front];
        printf("\nDeleted element is: %d\n", n);

        if(front == rear)
		{
            front = rear = -1;
        }
        else
		{
            front = (front + 1) % MAXSIZE;
        }
    }
}

void display()
{
int i = front;
    if(front == -1 && rear == -1)
	{
        printf("\nCIRCULAR QUEUE IS EMPTY\n");
    }
	else
	{
        printf("\nElements in the queue are: ");
        while(i != rear)
		{
            printf("%d ", deq[i]);
            i = (i + 1) % MAXSIZE;
        }
        printf("%d\n", deq[rear]);
    }
}
