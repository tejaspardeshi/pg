#include<stdio.h>
void main()
{
    int arr[10]={1,2,3,4,5,6,7,8,9,10};
    int item;
    int flag=0;

    printf("Enter the number that you want to Search between 1 to 10 : ");
    scanf("%d",&item);
    for(int i=0;i<=10;i++)
    {
        if(item==arr[i])
        {
            flag=1;
            break;
        }
    }
    if(flag==1)
    {
        printf("The founded item is %d",item);
    }
    else
    {
        printf("\nThe item is not found");
    }



}
