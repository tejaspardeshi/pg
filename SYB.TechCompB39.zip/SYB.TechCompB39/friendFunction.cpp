/*
#include<iostream>
using namespace std;
class BOX
{
    private:
        int length;
    public:
        BOX():
            length(1) { }
            friend int printLength(BOX);
};

int printLength(BOX b)
{
    b.length += 10;
    return b.length;
}
int main()
{
    BOX b;
    cout<<"Length of box: "<<printLength(b)<<endl;
    return 0;
}
*/
