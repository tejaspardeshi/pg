
#include<iostream>
using namespace std;

class Distance
{
    private:
        int feet;
        int inches;
    public:
        // Constructor
        Distance()
        {
            feet = 0;
            inches = 0;
        }
        Distance(int f, int i)
        {
            feet = f;
            inches = i;
        }

        // Method to display distance
        void displayDistance() {
            cout << "Feet: " << feet << " Inches: " << inches << endl;
        }

        // Overloaded unary minus (-) operator
        Distance operator- () {
            feet = -feet;
            inches = -inches;
            return Distance(feet, inches);
        }
};

int main()
{
    Distance D1(11, 10), D2(-5, 11);

    D1 = -D1;
    D1.displayDistance();  // Display D1

    D2 = -D2;
    D2.displayDistance();  // Display D2

    return 0;
}
