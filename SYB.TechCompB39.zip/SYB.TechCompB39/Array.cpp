/*
#include<iostream>
using namespace std;
int main()
{
    int a[10],n;
    cout<<"Enter the number of element:\n";
    cin>>n;
    cout<<"Enter The array Elements:\n";
    for (int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<"The array Elements are:\n";
    for (int i=0;i<n;i++)
    {
        cout<<a[i];
        cout<<"\n";
    }
}
*/
