/*
#include<iostream>
using namespace std;
int main()
{
    cout<<"Welcome to object oriented programming";
    return 0;
}*/
