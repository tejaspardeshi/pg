/*
#include<iostream>
using namespace std;
void arith(int a,int b);
void rel(int a,int b);
void Logic(int a,int b);
void bitwise(int a,int b);
int main()
{
    int a,b;
    cout<<"Enter The Two Numbers :\n";
    cin>>a>>b;
    arith(a,b);
    rel(a,b);
    Logic(a,b);
    bitwise(a,b);
    return 0;
}
inline void arith(int a,int b)
{
    bool result;
    cout<<"\n******* The Arithmetic Operators *******\n"<<endl;
    cout<<"The Sum of two Numbers is :"<<a+b<<endl;
    cout<<"The Subtraction of two Numbers is :"<<a-b<<endl;
    cout<<"The Product of two Numbers is :"<<a*b<<endl;
    cout<<"The Divide of two Numbers is :"<<a/b<<endl;
    cout<<"The Reminder is :"<<a%b<<endl;
}
inline void rel(int a,int b)
{
    bool result;
    cout<<"\n******* The Relational Operators *******\n"<<endl;
    result = (a==b);
    cout<<"The output of a==b is : "<<result<<endl;
    result = (a!=b);
    cout<<"The output of a!=b is : "<<result<<endl;
    result = (a>b);
    cout<<"The output of a>b is  : "<<result<<endl;
    result = (a<b);
    cout<<"The output of a<b is  : "<<result<<endl;
    result = (a>=b);
    cout<<"The output of a>=b is : "<<result<<endl;
    result = (a<=b);
    cout<<"The output of a<=b is : "<<result<<endl;
}
inline void Logic(int a,int b)
{
    bool result;
    cout<<"\n******* The Logic Operators *******\n"<<endl;
    result = (a==b) && (a>b);
    cout<<"The output of (a==b) && (a>b) is : "<<result<<endl;
    result = (a==b) || (a>b);
    cout<<"The output of (a==b) || (a>b) is : "<<result<<endl;
    result = (a==b) != (a>b);
    cout<<"The output of (a==b) != (a>b) is : "<<result<<endl;
}
inline void bitwise(int a,int b)
{
    bool result;
    cout<<"\n******* The Bitwise Operators *******\n"<<endl;
    result = (a&b);
    cout<<"The output of (a&b) is : "<<result<<endl;
    result = (a|b);
    cout<<"The output of (a|b) is : "<<result<<endl;
    result = !(a>b);
    cout<<"The output of != (a>b) is : "<<result<<endl;
}
*/
