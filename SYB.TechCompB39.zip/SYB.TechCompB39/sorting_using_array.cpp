/*
#include<iostream>
using namespace std;
int main()
{
    int i,j,arr[10],temp,n;
    cout<<"Enter the number of Elements : ";
    cin>>n;
    cout<<"\nEnter the array Elements : ";
    for(i=0; i<n; i++)
    {
        cin>>arr[i];
    }
    cout<<"\nThe array elements are : ";
    for(i=0;i<n;i++)
    {
        cout<<arr[i]<<endl;
    }

    for(i=0;i<(n-1);i++)
    {
        for(j=0;j<(n-i-1);j++)
        {
            if(arr[j]>arr[j+1])
            {
                temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    cout<<"\nThe array elements are sorted Successfully: ";
    cout<<"\nThe new array Elements are : ";
    for(i=0; i<n; i++)
    {
        cout<<arr[i]<<endl;
    }
    return 0;
}
*/
